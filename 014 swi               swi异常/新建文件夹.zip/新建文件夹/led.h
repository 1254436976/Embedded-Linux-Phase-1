

#ifndef _LED_H
#define _LED_H

void delay(volatile int d);
int led_test(void);


#endif

