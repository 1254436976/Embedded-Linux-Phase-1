

#ifndef _SDRAM_INIT_H
#define _SDRAM_INIT_H

void sdram_init(void);
int sdram_test(void);
	
#endif

